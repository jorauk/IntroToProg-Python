# ------------------------------------------------- #
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Jonathan Mauk, 11/6/17, Added code to complete assignment 6
# https://www.tutorialspoint.com/python/python_dictionary.htm
# ------------------------------------------------- #

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------


# variable for reading file

# empty table we will work with

# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"


# print(lstTable)
# This is a print statement I used to test that the code above works

# Step 2 - Display a menu of choices to the user


class ToDoList(object):
    lst_table = []
    objfilename = open("C:\\_PythonClass\\Todo.txt")

    for line in objfilename:
        (key, val) = line.rstrip().split(',')
        dicRow = {key: val}
        lst_table.append(dicRow)

    @staticmethod
    def first_choice():
        for item in ToDoList.lst_table:
            print(item)

    @staticmethod
    def second_choice():
        chore_input = input("Please enter a chore or task that needs doing: ")
        priority_input = input("Please enter the priority of this task (low, medium, high): ")
        ToDoList.lst_table.append({chore_input: priority_input})  # appends new dictionary

    @staticmethod
    def third_choice_a():
        ToDoList.lst_table.pop()  # .pop removes most recent task added

    @staticmethod
    def fourth_choice_a():
        write_string = ""
        objfilewrite = open("C:\\_PythonClass\\Todo.txt", "w")  # overwrites file
        for item in ToDoList.lst_table:
            for row in item:
                comma_join = row + "," + item[row]
                write_string = write_string + comma_join + '\n'
        objfilewrite.write(write_string)
        objfilewrite.close()


while True:
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item
    3) Remove most recently added item
    4) Save data to file
    5) Exit program
    """)
    strChoice = str(input("Please select an option. (1 - 5) - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if strChoice.strip() == '1':
        ToDoList.first_choice()
        continue
    # Step 4 - Add a new item to the list/Table
    elif strChoice.strip() == '2':
        ToDoList.second_choice()
        continue
    # Step 5 - Remove a new item to the list/Table
    elif strChoice == '3':
        ToDoList.first_choice()  # prints contents of list as a reminder
        deleteTask = input("Delete most recently-added item? (Y/N) ")
        if deleteTask.lower() == "y":
            ToDoList.third_choice_a()
            continue
        elif deleteTask.lower() == "n":
            print("Deletion cancelled. Returning to main menu.")
            continue
        else:
            print("Invalid input. Returning to main menu.")
            continue
    # Step 6 - Save tasks to the Todo.txt file
    elif strChoice == '4':
        saveInput = input("Save current list to Todo.txt? (Y/N) ")
        if saveInput.lower() == "y":
            ToDoList.fourth_choice_a()
            print("File saved. Returning to main menu.")
            continue
        elif saveInput.lower() == "n":
            print("Save cancelled. Returning to main menu.")
            continue
        else:
            print("Invalid input. Returning to main menu.")
            continue
    elif strChoice == '5':
        exitSave = input("Would you like to save before exiting? (Y/N)")
        if exitSave.lower() == "y":
            ToDoList.fourth_choice_a()
            print("File saved. Exiting program. Goodbye!")
            break
        else:
            print("Exiting program. Goodbye!")
            break  # and exit the program
